[//]: # (TODO: fix links to repository)

# pyglasma3d_numba
[![pipeline status](https://gitlab.com/yumasheta/test-ci/badges/master/pipeline.svg)](https://gitlab.com/yumasheta/test-ci/commits/master)
[![coverage report](https://gitlab.com/yumasheta/test-ci/badges/master/coverage.svg)](https://gitlab.com/yumasheta/test-ci/commits/master)
[![Code Style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

### A 3D Glasma Simulation implemented in Python using the [Numba](http://numba.pydata.org/) framework.
The code is based on the [pyglasma3d](https://gitlab.com/monolithu/pyglasma3d)
project which is implemented in Python and uses Cython for acceleration.

#### Full Documentation and Help is located [here](https://yumasheta.gitlab.io/test-ci)

## Roadmap

- v0.5  
  add comprehensive consistency test results
  add benchmark suite

- v0.5.1
  add benchmark results for v0.4.5 and v0.5

- v0.6
  move to standalone repository  

- v0.7  
  full documentation  
  full CUDA documentation of what is implemented  
  final documentation, properly done with GitLab Pages + minimal READMEs (short, links to wiki) 

- v0.X  
  will have the interpolate charges loops fixed  
  and optimal init? with unified jit and minimal copying  

- v1.0  
  final optimizations,  
  perfect code  

- v1.X / vX.X  
  adding more features from the original pyglasma3d code  
  porting necessary modules to python