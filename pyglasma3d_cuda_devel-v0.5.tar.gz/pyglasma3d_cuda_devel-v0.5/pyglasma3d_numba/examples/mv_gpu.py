"""A script for Au-Au collisions in the MV-model.

The main input parameters are the collision energy sqrt{s},
the infrared regulator m
and the box dimensions (LT, LL).

This is a simplified version of the mv.py script defaulting to cuda.
The simulation terminates after 7 iterations
"""

# TODO: split up into clean version and cuda debug version
#       rework docstring

import os
import time
import argparse
import numpy as np


# command line arguments parsing with argparse

# helper function to check steps arg
def check_steps(arg):
    """Checker for steps argument."""
    try:
        arg = int(arg)
        if arg % 2 == 0 and arg >= 2:
            return arg
        raise argparse.ArgumentTypeError(f"{arg} is not a multiple of 2")
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid check_steps value steps={arg}")


# set up argparse
parser = argparse.ArgumentParser(
    description="A script for Au-Au collisions in the MV-model.",
    formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    prog="python3 -m examples.mv_gpu",
)
parser.add_argument(
    "-o",
    "--output",
    type=str,
    default="mv_trial_gpu",
    metavar="<name>",
    dest="run",
    help='specify the <name> for the output file in "./output/T_<name>.dat"',
)
parser.add_argument(
    "-l", "--nl", type=int, default=64, dest="nx", help="longitudinal grid size"
)
parser.add_argument(
    "-t", "--nt", type=int, default=256, dest="nt", help="transverse grid size"
)
parser.add_argument(
    "-L",
    "--LL",
    type=float,
    default=6.0,
    dest="LL",
    help="longitudinal simulation box size in [fm]",
)
parser.add_argument(
    "-T",
    "--LT",
    type=float,
    default=6.0,
    dest="LT",
    help="transverse simulation box size in [fm]",
)
parser.add_argument(
    "-E",
    "--energy",
    type=float,
    default=200000.0,
    dest="sqrts",
    help="collision energy [MeV]",
    metavar="energy",
)
parser.add_argument("-m", type=float, default=200.0, help="infrared regulator [MeV]")
parser.add_argument(
    "-u",
    "--uv",
    type=float,
    default=10000.0,
    dest="uv",
    help="ultraviolet regulator [MeV]",
)
parser.add_argument(
    "-s",
    "--steps",
    type=check_steps,
    default=4,
    dest="steps",
    help="ratio between dt and aL in multiples of 2, has to be integer",
)
parser.add_argument(
    "--debug", action="store_true", help="set debug mode for verbose output"
)
parser.add_argument(
    "-d",
    "--device",
    type=str,
    default=os.environ.get("MY_NUMBA_TARGET", "cuda"),
    dest="device",
    choices=["cuda", "numba", "python"],
    help="set the target compute device; "
    'this will set the environment variable "MY_NUMBA_TARGET"',
)
parser.add_argument(
    "--sysinfo",
    action="store_true",
    default=bool(int(os.environ.get("SYSINFO", 0))),
    dest="sysinfo",
    help="toggle verbose system information dump on startup; "
    'this will set the environment variable "SYSINFO" to 1',
)
parser.add_argument(
    "--fastmath",
    type=int,
    default=os.environ.get("FASTMATH", 1),
    dest="fastmath",
    choices=[0, 1],
    help="configure use of fastmath; "
    'this will set the environment variable "FASTMATH"',
)

# parse args
args = parser.parse_args()

# evaluate environment variables to control numba

# set MY_NUMBA_TARGET
os.environ["MY_NUMBA_TARGET"] = args.device
# set FASTMATH
os.environ["FASTMATH"] = str(args.fastmath)
# set SYSINFO
os.environ["SYSINFO"] = str(int(args.sysinfo))


# simulation setup

# simulation specific imports have to occur after command line args
# have been evaluated (for numba target etc.)
# disable flake8 and pylint errors for that
# pylint: disable=wrong-import-position
import pyglasma3d_numba_source.interpolate as interpolate  # noqa: E402
import pyglasma3d_numba_source.mv as mv  # noqa: E402
from pyglasma3d_numba_source.core import Simulation  # noqa: E402

# import pyglasma3d_numba_source.data_io as data_io  # noqa: E402

# pylint: enable=wrong-import-position

# TODO: remove profiler controls for final version
if args.device == "cuda":
    from pyglasma3d_numba_source.core import cuda

# values inherited from the command line arguments

# filename
# data will end up in `./output/T_<run>.dat`
# run = 'mv_trial_gpu'  ==> args.run

# grid size (make sure that ny == nz): args.nx, args.nt, args.nt
# nx, ny, nz = 2048, 64, 64   # 3.87 GB
# nx, ny, nz = 2048, 32, 32   # 0.97 GB
# nx, ny, nz = 512, 128, 128   # 3.87 GB
# nx, ny, nz = 128, 128, 128   # 0.97 GB
# nx, ny, nz = 64, 256, 256   # 1.92 GB  ==> default
# nx, ny, nz = 64, 512, 512   # >8 GB

# transverse and longitudinal box widths [fm]
# LT = 6.0  ==> args.LT
# LL = 6.0  ==> args.LL

# collision energy [MeV]
# sqrts = 200.0 * 1000.0  ==> args.sqrts

# infrared and ultraviolet regulator [MeV]
# m = 200.0 ==> args.m
# uv = 10.0 * 1000.0  ==> args.uv

# ratio between dt and aL [int, multiple of 2]
# steps = 4  ==> args.steps

# option for debug
# debug = True  ==> args.debug
# TODO: remove the debug overwrite
args.debug = True

# The rest of the parameters are computed automatically.

# constants
hbarc = 197.3270  # hbarc [MeV*fm]
RAu = 7.27331  # Gold nuclear radius [fm]

# determine lattice spacings and energy units
aT_fm = args.LT / args.nt
E0 = hbarc / aT_fm
aT = 1.0
aL_fm = args.LL / args.nx
aL = aL_fm / aT_fm
a = [aL, aT, aT]
dt = aL / args.steps

# determine initial condition parameters
gamma = args.sqrts / 2000.0
Qs = np.sqrt((args.sqrts / 1000.0) ** 0.25) * 1000.0
alphas = 12.5664 / (18.0 * np.log(Qs / 217.0))
g = np.sqrt(12.5664 * alphas)
mu = Qs / (g * g * 0.75) / E0
uvt = args.uv / E0
ir = args.m / E0
sigma = RAu / (2.0 * gamma) / aL_fm * aL
sigma_c = sigma / aL

# number of evolution steps (max_iters) and output file path
max_iters = 2 * args.nx // 3
file_path = "./output/T_" + args.run + ".dat"

"""
    Initialization
"""

# set random seed for run to run comparability
np.random.seed(10)

# initialize simulation object
dims = [args.nx, args.nt, args.nt]
s = Simulation(
    dims=dims,
    a=a,
    dt=dt,
    g=g,
    iter_dims=[1, args.nx - 1, 0, args.nt, 0, args.nt],
    debug=args.debug,
)

t = time.time()
print(f"[t={s.t}]: Initializing left nucleus.")
v = mv.initialize_mv(
    s, x0=args.nx * 0.25 * aL, mu=mu, sigma=sigma, mass=ir, uvt=uvt, orientation=+1
)
interpolate.initialize_charge_planes(s, +1, 0, args.nx // 2)
print("Initialized left nucleus in:", round(time.time() - t, 3))

t = time.time()
print(f"[t={s.t}]: Initializing right nucleus.")
v = mv.initialize_mv(
    s, x0=args.nx * 0.75 * aL, mu=mu, sigma=sigma, mass=ir, uvt=uvt, orientation=-1
)
interpolate.initialize_charge_planes(s, -1, args.nx // 2, args.nx)
print("Initialized right nucleus in:", round(time.time() - t, 3))

# TODO: remove profiler controls for final version
if args.device == "cuda":
    cuda.profile_start()

s.init()


# Simulation loop

# TODO: the calculations in s.log() are done but not printed if
#       debug is not set... useless compute cycles

t = time.time()
for it in range(max_iters):
    s.log("\n" + s.mem_info() + "\n")

    # this for loop moves the nuclei exactly one grid cell
    for step in range(args.steps):
        t = time.time()
        s.evolve()
        s.log(s.t, "Complete cycle in:", round(time.time() - t, 3))

    t = time.time()
    s.log(
        "\nGauss constraint squared, avg over simulation box: "
        f"{s.gauss_constraint_squared():.2e}"
    )
    s.log("Writing energy momentum tensor to file.\n")
    s.write_energy_momentum(max_iters, file_path)
    print(
        f"[t={s.t}]: Iteration step",
        it + 1,
        "/",
        max_iters,
        "complete in:",
        round(time.time() - t, 3),
    )

    # TODO: remove limit to 7 iterations
    if it > 5:
        break

# TODO: remove profiler controls for final version
if args.device == "cuda":
    cuda.profile_stop()


# convert binary output file to readable txt


# print('\n\nconverting binary output file to text file...')
# data_io.write('./output/T_' + args.run + '_textfile.dat',
#   **data_io.read(file_path)
# )
# TODO: add a code sample for how to use data_io.read_iter
#  to iterate over a binary file and produce the same text file as above
