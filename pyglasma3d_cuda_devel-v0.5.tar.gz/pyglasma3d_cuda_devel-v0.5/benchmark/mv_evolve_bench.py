"""BENCHMARK VERSION.

This is a simplified version of the mv.py script and is used for
benchmarking. It uses timeit to measure the time per evolve step for
a total of 20 iterations.
"""

# pylint: disable=unused-import

from __future__ import print_function

import argparse
import gc  # noqa: F401
import os
import time
from timeit import timeit

import numpy as np


# command line arguments parsing with argparse

# helper function to check steps arg
def check_steps(arg):
    """Checker for steps argument."""
    try:
        arg = int(arg)
        if arg % 2 == 0 and arg >= 2:
            return arg
        raise argparse.ArgumentTypeError("{} is not a multiple of 2".format(arg))
    except ValueError:
        raise argparse.ArgumentTypeError(
            "invalid check_steps value steps={}".format(arg)
        )


# TODO: reorder args, like mv_gpu. alphabetic in categories
# set up argparse
parser = argparse.ArgumentParser(
    description="A benchmark setup script.",
    formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    prog="python -m examples.mv_evolve_bench",
)
parser.add_argument(
    "-o",
    "--output",
    type=str,
    default="mv_evolve_bench",
    metavar="<name>",
    dest="run",
    help='specify the <name> for the output file in "./output/T_<name>.dat"',
)
parser.add_argument(
    "-l", "--nl", type=int, default=64, dest="nx", help="longitudinal grid size"
)
parser.add_argument(
    "-t", "--nt", type=int, default=256, dest="nt", help="transverse grid size"
)
parser.add_argument(
    "-L",
    "--LL",
    type=float,
    default=6.0,
    dest="LL",
    help="longitudinal simulation box size in [fm]",
)
parser.add_argument(
    "-T",
    "--LT",
    type=float,
    default=6.0,
    dest="LT",
    help="transverse simulation box size in [fm]",
)
parser.add_argument(
    "-E",
    "--energy",
    type=float,
    default=200000.0,
    dest="sqrts",
    help="collision energy [MeV]",
    metavar="energy",
)
parser.add_argument("-m", type=float, default=200.0, help="infrared regulator [MeV]")
parser.add_argument(
    "-u",
    "--uv",
    type=float,
    default=10000.0,
    dest="uv",
    help="ultraviolet regulator [MeV]",
)
parser.add_argument(
    "-s",
    "--steps",
    type=check_steps,
    default=4,
    dest="steps",
    help="ratio between dt and aL in multiples of 2, has to be integer",
)
parser.add_argument(
    "--debug", action="store_true", help="set debug mode for verbose output"
)
parser.add_argument(
    "-d",
    "--device",
    type=str,
    default=os.environ.get("MY_NUMBA_TARGET", "cuda"),
    dest="device",
    choices=["cuda", "numba", "cython"],
    help="set the target compute device; "
    'this will set the environment variable "MY_NUMBA_TARGET"'
    "and run the appropriate code for each device.",
)
parser.add_argument(
    "--fastmath",
    type=int,
    default=os.environ.get("FASTMATH", 1),
    dest="fastmath",
    choices=[0, 1],
    help="configure use of fastmath; "
    'this will set the environment variable "FASTMATH"',
)

# parse args
args = parser.parse_args()

# evaluate environment variables to control numba

# set MY_NUMBA_TARGET
os.environ["MY_NUMBA_TARGET"] = args.device
# set FASTMATH
os.environ["FASTMATH"] = str(args.fastmath)


# simulation setup

# simulation specific imports have to occur after command line args
# have been evaluated (for numba target etc.)
# disable flake8 and pylint errors for that
# pylint: disable=wrong-import-position,import-error
if args.device == "cython":
    import pyglasma3d.cy.mv as mv
    import pyglasma3d.cy.interpolate as interpolate
    import pyglasma3d.cy.gauss as gauss
    from pyglasma3d.core import Simulation

else:
    # device == cuda | numba
    import pyglasma3d_numba_source.interpolate as interpolate  # noqa: E402
    import pyglasma3d_numba_source.gauss as gauss  # noqa: E402,F401
    import pyglasma3d_numba_source.mv as mv  # noqa: E402
    from pyglasma3d_numba_source.core import Simulation  # noqa: E402


if args.device == "cuda":
    from pyglasma3d_numba_source.core import cuda  # noqa: E402

    # define cuda synchronize
    def cuda_sync():
        """Run cuda.synchronize()."""
        cuda.synchronize()


else:
    # skip cuda synchronize
    def cuda_sync():
        """Skip cuda.synchronize()."""


# values inherited from the command line arguments

# filename
# data will end up in `./output/T_<run>.dat`
# run = 'mv_trial_gpu'  ==> args.run

# grid size (make sure that ny == nz): args.nx, args.nt, args.nt
# nx, ny, nz = 2048, 64, 64   # 3.87 GB
# nx, ny, nz = 2048, 32, 32   # 0.97 GB
# nx, ny, nz = 512, 128, 128   # 3.87 GB
# nx, ny, nz = 128, 128, 128   # 0.97 GB
# nx, ny, nz = 64, 256, 256   # 1.92 GB  ==> default
# nx, ny, nz = 64, 512, 512   # >8 GB

# transverse and longitudinal box widths [fm]
# LT = 6.0  ==> args.LT
# LL = 6.0  ==> args.LL

# collision energy [MeV]
# sqrts = 200.0 * 1000.0  ==> args.sqrts

# infrared and ultraviolet regulator [MeV]
# m = 200.0 ==> args.m
# uv = 10.0 * 1000.0  ==> args.uv

# ratio between dt and aL [int, multiple of 2]
# steps = 4  ==> args.steps

# option for debug
# debug = True  ==> args.debug


# The rest of the parameters are computed automatically.

# constants
hbarc = 197.3270  # hbarc [MeV*fm]
RAu = 7.27331  # Gold nuclear radius [fm]

# determine lattice spacings and energy units
aT_fm = args.LT / args.nt
E0 = hbarc / aT_fm
aT = 1.0
aL_fm = args.LL / args.nx
aL = aL_fm / aT_fm
a = [aL, aT, aT]
dt = aL / args.steps

# determine initial condition parameters
gamma = args.sqrts / 2000.0
Qs = np.sqrt((args.sqrts / 1000.0) ** 0.25) * 1000.0
alphas = 12.5664 / (18.0 * np.log(Qs / 217.0))
g = np.sqrt(12.5664 * alphas)
mu = Qs / (g * g * 0.75) / E0
uvt = args.uv / E0
ir = args.m / E0
sigma = RAu / (2.0 * gamma) / aL_fm * aL
sigma_c = sigma / aL

# output file path
file_path = "./output/T_" + args.run + ".dat"

"""
    Initialization
"""

# initialize simulation object
dims = [args.nx, args.nt, args.nt]
s = Simulation(
    dims=dims, a=a, dt=dt, g=g, iter_dims=[1, args.nx - 1, 0, args.nt, 0, args.nt]
)
# manual work around for cython version
s.debug = args.debug

t = time.time()
print("[t={}]: Initializing left nucleus.".format(s.t))
v = mv.initialize_mv(
    s, x0=args.nx * 0.25 * aL, mu=mu, sigma=sigma, mass=ir, uvt=uvt, orientation=+1
)
interpolate.initialize_charge_planes(s, +1, 0, args.nx // 2)
print("Initialized left nucleus in:", round(time.time() - t, 3))

t = time.time()
print("[t={}]: Initializing right nucleus.".format(s.t))
v = mv.initialize_mv(
    s, x0=args.nx * 0.75 * aL, mu=mu, sigma=sigma, mass=ir, uvt=uvt, orientation=-1
)
interpolate.initialize_charge_planes(s, -1, args.nx // 2, args.nx)
print("Initialized right nucleus in:", round(time.time() - t, 3))

s.init()


# Simulation loop


def sim_loop():
    """Move the nuclei exactly one grid cell."""
    for _ in range(args.steps):
        s.evolve()

    cuda_sync()


# call once to compile all numba kernels
sim_loop()

max_iters = 20

# run the main loop as part of timeit
# timeit turns off garbage collection; turn it back on
t = timeit("sim_loop()", "from __main__ import sim_loop; gc.enable()", number=max_iters)
avg_t = t / max_iters
result = '{{"total": {}, "avg": {}}}'.format(t, avg_t)

# save the result in tmp file for readout by run_benchmark.sh script
with open("embedded_result.dat", "w") as f:
    f.write(result)
