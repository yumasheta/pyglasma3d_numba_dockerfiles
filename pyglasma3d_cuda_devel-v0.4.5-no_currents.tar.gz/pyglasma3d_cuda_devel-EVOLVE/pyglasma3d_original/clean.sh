#!/usr/bin/env bash
# cleanup
rm ./pyglasma3d/cy/*.c
rm ./pyglasma3d/cy/*.so
rm ./pyglasma3d/cy/*.html
rm -R ./build