---
weight: 9
# bookFlatSection: true
bookCollapseSection: true
title: "Wiki Maintenance Guide"
---


# Basic Setup

<!-- #TODO:
    - explain backend (hugo)
    - explain gitlab pages setup
    -  -->