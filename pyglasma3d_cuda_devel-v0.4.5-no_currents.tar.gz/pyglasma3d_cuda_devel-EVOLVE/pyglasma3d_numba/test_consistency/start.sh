#!/usr/bin/env bash

########################################################################
# This script offers selection of different preconfigured testing
# scenarios. First the selected simulation setup will be run. Then the
# output data it produced will be checked using the
# `consistency_tests.py` script (except for option 5).
########################################################################

# change current working dir to base folder of pyglasma3d_numba
cd -P -- "$(dirname -- "${BASH_SOURCE[0]}")"
cd ..
# pwd
# [...]/pyglasma3d_numba

# a loop to select options
choice=11

while [ $choice -eq 11 ]; do

    echo -e "\nplease input the number of the setup to run...\n"
    echo "1 => test pyglasma3d_numba mv_simple setup with fastmath = True"
    echo "2 => test pyglasma3d_numba mv_simple setup with fastmath = False"
    echo "3 => test pyglasma3d_numba mv_simple setup in cuda mode with fastmath = True"
    echo "4 => test pyglasma3d_numba mv_simple setup in cuda mode with fastmath = False"
    echo "5 => time pyglasma3d_numba mv_gpu setup in cuda mode for 7 iterations \
with fastmath = True"
    echo -e "q => ABORT\n"

    read choice
    echo -n "your choice was: "
    echo $choice
    echo -e "\n\n\n\n"

    # default arguments for the consistency test
    args="-f original/T_mv_trial_simple_cython_textfile.dat \
../output/T_mv_trial_simple_textfile.dat -v"
    run_test=True
    setup="examples.mv_simple"

    case $choice in
        1)
            args=$args" --fastmath"
            ;;
        2)
            export FASTMATH=0
            ;;
        3)
            export MY_NUMBA_TARGET=cuda
            args=$args" --fastmath"
            ;;
        4)
            export MY_NUMBA_TARGET=cuda
            export FASTMATH=0
            ;;
        5)
            run_test=False
            setup="examples.mv_gpu"
            ;;
        q)
            echo "aborting..."
            exit
            ;;
        *)
            echo "this does not match any inputs. please try again"
            echo "------------------------------------------------"
            choice=11
            ;;
    esac

done

time python3 -m $setup

# calc statistics if required
if [[ "$run_test" == True ]]; then

  echo -e "\ncalling 'consistency_test.py' with the following arguments:" \
"\n\t consistency_test.py $args\n"
  cd test_consistency
  ./consistency_tests.py $args

fi