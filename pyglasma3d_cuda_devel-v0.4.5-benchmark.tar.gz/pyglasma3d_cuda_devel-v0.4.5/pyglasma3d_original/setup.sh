#!/usr/bin/env bash
# build cython code
python2 setup.py build_ext --inplace
